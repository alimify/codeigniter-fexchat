<?php

$this->load->view('fexchat/header');
$this->load->view('fexchat/'.$load);
$this->load->view('fexchat/footer');